 -- DISPLAY ALL THOSE EMPLOYEES WHO ARE UNDER KING
 use Northwind
 
 select * from employees where ReportsTo= (select employeeid from employees where lastname='King')