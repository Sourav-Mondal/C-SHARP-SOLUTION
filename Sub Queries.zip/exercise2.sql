--Find the titles that obtain a larger advance than the minimum paid by  �Algodata Infosystems�


 select distinct t.title from titles t where t.advance >t.price and t.price in 
 (select t.price from titles t ,publishers p where t.pub_id=p.pub_id and  p.pub_name='Algodata Infosystems')