--  DISPLAY THOSE EMPLOYEES WHOSE SALARY IS MORE THAN THE AVERAGE SALARY OF DEPARTMENT 20
use pubs

select concat(fname,' ',lname) as 'full name' from employee where salary>(select avg(salary) from department where deptid=20)