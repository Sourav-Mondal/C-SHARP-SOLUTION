--  	DISPLAY THOSE EMPLOYEES WHO ARE IN SALES DEPARTMENT AND WORKING UNDER KING OR JONES
use northwind

select concat(firstname,' ',lastname) as 'full name' from employees where deptid=(select deptid from department  where deptname='sales')
and ReportsTo=(select EmployeeID from employees where firstname='King') or ReportsTo=(select EmployeeID from employees where firstname='Jones') 