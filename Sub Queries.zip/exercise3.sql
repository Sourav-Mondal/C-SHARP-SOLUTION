--You, as sales person, want to find out the names of all those books  whose price is higher than that of all business books.
--Write a query to achieve this?

select title from titles where price>(select max(price)from titles where type='business')