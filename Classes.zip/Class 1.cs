using System;
class Car {
    String carMake;
    int mfgYear;
    int carmodel;
    String city;
    
    public Car()
    {
        carMake= "Ford";
        mfgYear=1876;
        carmodel=78;
        city="Chennai";
    } 
    public void displayCar()
  {
 
    Console.WriteLine(carMake);
    Console.WriteLine(mfgYear);
    Console.WriteLine(carmodel);
    Console.WriteLine(city);
    Console.Read();
  }
}
class Program
{
   static void Main() 
   {
    Car obj= new Car();  
     obj.displayCar();  
}
}
