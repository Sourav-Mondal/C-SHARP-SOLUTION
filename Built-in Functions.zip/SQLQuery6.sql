--  DISPLAY THOSE EMPLOYEES WHOSE SALARY ENDS WITH 0


use pubs

select concat(fname,' ',lname) as 'full name' from employee where salary LIKE '%0'