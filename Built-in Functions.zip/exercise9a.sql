use pubs

select concat(fname,' ',minit,' ',lname) from employee  where datediff(dd,day(hire_date),day(eomonth(hire_date))) between 1 and 3
