--  DISPLAY THOSE EMPLOYEES WHOSE SALARY IS 2000,3000 AND 5000 AND JOB IS ANALYST OR PRESIDENT WHILE THEY JOINED THE COMPANY IN THE YEAR 1981.

use pubs

select concat(fname,' ',lname) as 'full name' from employee where salary=2000 or salary=3000 or salary=5000 and job='analyst' or job='president'
and year(hire_date)='1981'