
use pubs
select substring(fname,(len(fname)-3)+1,3) from employee
