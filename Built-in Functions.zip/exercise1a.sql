
use pubs
-- DISPLAY THOSE EMPLOYEES WHO JOINED THE COMPANY IN THE FIRST THREE MONTHS OF ANY YEAR
select concat(fname,' ',lname) from employee where (month(hire_date)) between 1 and 3;