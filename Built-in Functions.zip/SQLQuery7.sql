--   DISPLay THOSE EMPLOYEES WHOSE SALARY IS AN ODD NUMBER.


use pubs

select concat(fname,' ',lname) as 'full name' from employee where (salary%2)!=0