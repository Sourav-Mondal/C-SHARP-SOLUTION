use pubs
select concat(lower((SUBSTRING(fname,1,1))),upper((substring(fname,2,len(fname))))) from employee