
use pubs
--DISPLAY THE EMPLOYEE NAME AND AS MANY STARS(*) AS THE NUMBER OF CHARACTERS WITHIN THAT NAME.
select fname ,REPLICATE('*',len(fname)) as 'many stars(*)' from employee
