-- DISPLAY THOSE EMPLOYEES WHOSE SALARY IS OF THREE DIGITS.

use pubs

select concat(fname,' ',lname) as 'full name' from employee where datalength(salary)=3