﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a =int.Parse( textBox7.Text);
            string b = textBox6.Text;
            int c = int.Parse(textBox5.Text);
            int d = int.Parse(textBox4.Text);
            int h = int.Parse(textBox3.Text);
            string f = textBox2.Text;
            int g = int.Parse(textBox1.Text);
            int i = 0;
            int j = a;
            int k = g;

            if (j != 123 )
            {
                label2.ForeColor = Color.Red;
                label2.Text = "Not Valid";
                    i++;
            }
           
            if (b == string.Empty)
            {
                label4.ForeColor = Color.Red;
                label4.Text = "Cannot Be Empty";
                i++;
            }
            if (c > 11 && d > 04 && h > 2020)
            {
                label9.ForeColor = Color.Red;
                label9.Text = "Invalid Date";
                i++;
            }
             if (f != "EE" )
            {
                label11.ForeColor = Color.Red;
                label11.Text = "Invalid";
                i++;
            }
          
       

            if (g < 10000 || g > 50000000)
            {
                label13.ForeColor = Color.Red;
                label3.Text = "Salary Not Found";
                i++;
            }
            else if(i==0)
                MessageBox.Show("Employee Present");
        }
    }
}
