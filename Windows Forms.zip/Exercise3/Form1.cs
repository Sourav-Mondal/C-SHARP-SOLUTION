﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lblbutton1.Text = "21";
            lblbutton2.Text = "45";
            lblbutton3.Text = "57";
            int i = int.Parse( lblbutton1.Text);
            int j = int.Parse(lblbutton2.Text);
            int k = int.Parse(lblbutton3.Text);
            int l = i + j + k;
            if (l % 2 == 0)
                MessageBox.Show("You Won");
            else
                MessageBox.Show("Oops!Try Next Time");
        }
    }
}
