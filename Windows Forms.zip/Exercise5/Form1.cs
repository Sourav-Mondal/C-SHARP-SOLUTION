﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Exercise5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DriveInfo[] drive = DriveInfo.GetDrives();
            foreach (DriveInfo d in drive)
            {
                comboBox1.Items.Add(d.Name);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int a = comboBox1.SelectedIndex;
            if (a == 0)
            {
                DirectoryInfo info = new DirectoryInfo(@"C:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }
            }
            else if (a == 1)
            {
                listBox1.Items.Clear();
                DirectoryInfo info = new DirectoryInfo(@"D:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }
            }
            else if (a == 2)
            {
                listBox1.Items.Clear();
                DirectoryInfo info = new DirectoryInfo(@"E:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }
            }
            else
            {
                listBox1.Items.Clear();
                DirectoryInfo info = new DirectoryInfo(@"F:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }

            }
        }
    }
}
