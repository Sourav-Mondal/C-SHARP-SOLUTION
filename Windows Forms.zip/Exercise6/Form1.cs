﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Exercise6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string t = textBox1.Text;

            if (t == "C")
            {
                DirectoryInfo info = new DirectoryInfo(@"C:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }
            }
            else if (t == "D")
            {
                listBox1.Items.Clear();
                DirectoryInfo info = new DirectoryInfo(@"D:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }


            }
            else if (t == "E")
            {
                listBox1.Items.Clear();
                DirectoryInfo info = new DirectoryInfo(@"E:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }
            }
            else if (t == "F")
            {
                listBox1.Items.Clear();
                DirectoryInfo info = new DirectoryInfo(@"F:\");
                DirectoryInfo[] folder = info.GetDirectories();
                FileInfo[] files = info.GetFiles();
                foreach (FileInfo file in files)
                {
                    listBox1.Items.Add(file.Name);
                }
                foreach (DirectoryInfo g in folder)
                {
                    listBox1.Items.Add(g.Name);
                }

            }
            else
                MessageBox.Show("No Drive Present");
        }
    }
}
