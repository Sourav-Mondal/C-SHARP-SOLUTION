use pubs

insert into department values(56,'sales',12)