use pubs

update employee set job_id= 14  where fname=' Pedro Afonso'
