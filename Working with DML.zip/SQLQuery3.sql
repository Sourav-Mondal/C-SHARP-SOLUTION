use pubs
select * from employee
insert into employee values('PMJ78269L','Sourav',' ','Mondal',122,225,0899,'1993-09-28 00:00:00')