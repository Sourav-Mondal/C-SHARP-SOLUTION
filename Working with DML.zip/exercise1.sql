use pubs

-- Change the last name of employee �VPA30890F� to Drexler
update employee set lname='Drexler' where emp_id='VPA30890F'
