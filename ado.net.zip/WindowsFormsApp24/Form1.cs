﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApp24
{
    public partial class Form1 : Form

    {

        SqlCommand cmd;
        SqlDataReader dr;



        public Form1()
        {
            InitializeComponent();


            SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-V9F5C27O\MSSQLSERVER03;Initial Catalog=Northwind;Integrated Security=True");
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "select FirstName + LastName as fullname from Employees";
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
              var a = dr["FullName"];
              
             

                listBox1.Items.Add(a);
              
            }
            con.Close();


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           
        }

      
    }
}
