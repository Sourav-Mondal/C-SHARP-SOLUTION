using System;
class RandomHelper{
    public static int Randint(int a,int b)
    {
       
        Random r = new Random();
      int genRand= r.Next(a,b);
      return genRand;
      
    }
    public static double Randdouble(int a,int b)
    {
        
        Random r = new Random();
      double genR= (r.NextDouble()*(b-a))+a;
      return genR;
    }
    
}
class Program
{
    public static void Main() 
    {
        int x,y;
        x=Convert.ToInt32(Console.ReadLine());
        y=Convert.ToInt32(Console.ReadLine());
       
    int num=RandomHelper.Randint(x,y);
    double dub=RandomHelper.Randdouble(x,y);
    Console.WriteLine(num);
    Console.WriteLine(dub);
  }
}