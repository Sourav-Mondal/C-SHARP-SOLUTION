using System;
class Employee {
    string emp_name;
    double basic, hra,da,gross,net,tax;
    public void CalculateNetPay()
    {
        hra=0.15*basic;
        da=0.10*basic;
        gross=basic+hra+da;
        tax=0.08*gross;
        net=gross-tax;
    }
    public Employee()
    {
        emp_name=Console.ReadLine();
        basic=Convert.ToDouble(Console.ReadLine());
    }
    public void display()
    {
        CalculateNetPay();
        Console.WriteLine("Employee Name: "+emp_name);
        Console.WriteLine("HRA: "+hra);
        Console.WriteLine("DA: "+da);
        Console.WriteLine("Gross Pay: "+gross);
        Console.WriteLine("Tax: "+tax);
        Console.WriteLine("Net Salary: "+net);
    }
}
class Program
{
    static void Main() 
    {
    Employee emp=new Employee();    
    emp.display();
  }
}

