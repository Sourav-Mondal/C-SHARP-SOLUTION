using System;
class Fan{
    public static int slow=1,medium=2,fast=3;
    private int Speed;
    private bool On;
    private double Radius;
    private String Color;
    public Fan()
    {    }
    public void setSpeed( int speed ) {
        Speed=speed;
      }

      public double getSpeed() {
         return Speed;
      }
      
      public void setOn( bool on ) {
         On=on;
      }

      public bool getOn() {
         return On;
      }
      
      public void setRadius( double radius ) {
         Radius=radius;
      }

      public double getRadius() {
         return Radius;
      }
      
      public void setColor( String color) {
         Color=color;
      }

      public String getColor() {
         return Color;
      }
}
class program
{
 static void Main() {
     Fan f = new Fan();
f.setRadius(5);
f.setOn (false);
f.setSpeed(1);
f.setColor("Red");
    Console.WriteLine("Fan Speed: "+f.getSpeed());
     Console.WriteLine("Fan Color: "+f.getColor());
      Console.WriteLine("Fan Radius: "+f.getRadius());
       Console.WriteLine("Fan On: "+f.getOn());
    
    
  }
}