using System;
class Stock {
    string st_name,st_sym;
    double prev,cur;
    public double getChangePercentage()
    {
        return ((prev-cur)/prev)*100;
    }
    public Stock()
    {
        st_name=Console.ReadLine();
        st_sym=Console.ReadLine();
        prev=Convert.ToDouble(Console.ReadLine());
        cur=Convert.ToDouble(Console.ReadLine());
    }
    public void display()
    {
        double  tot=getChangePercentage();      
        Console.WriteLine("Stock Name: "+st_name);
        Console.WriteLine("Stock Symbol: "+st_sym);
        Console.WriteLine("Percentage Change: "+ tot);
      
    }
}
class Program
{
    static void Main() 
    {
    Stock st =new Stock();    
    st.display();
  }
}