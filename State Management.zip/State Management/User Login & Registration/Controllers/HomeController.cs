﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DatabaseConnWebApplication.Models;
namespace DatabaseConnWebApplication.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Homepage()
        {
            return View();
        }

        public ActionResult Login()
        {
            ViewBag.Message = null;
            return View();
        }
        public ActionResult CheckLogin()
        {
            string id = Request.Form["id"];
            string pwd = Request.Form["password"];
            if (validateID(id) && validatePwd(pwd))
            {
                User user = searchUser(id);
                if (user != null)
                {
                    if (user.UserID.Equals(id) && user.UserPassword.Equals(pwd))
                    {
                        ViewBag.Message = null;
                        Response.Cookies["UserName"].Value = user.UserName;
                        Response.Cookies["UserID"].Value = user.UserID;
                        return View("About");
                    }
                    else
                    {
                        ViewBag.Message = "Invalid Password";
                        return View("Login");
                    }
                }
                else
                {
                    ViewBag.Message = "User Does Not Exist";
                    return View("Login");
                }
            }
            else
            {
                ViewBag.Message = "Id and Password cannot be Null";
                return View("Login");
            }
        }

        public ActionResult Register()
        {
            ViewBag.Message = null;

            return View();
        }
        public ActionResult NewRegister()
        {
            string id = Request.Form["id"];
            string name = Request.Form["name"];
            string pwd = Request.Form["password"];
            if(validateName(name) && validateID(id) && validatePwd(pwd))
            {
                User user = new User(id, name, pwd);
                if (addUser(user))
                {
                    ViewBag.Message = "Registration Successful";
                    return View("Login");
                }
                else
                {
                    ViewBag.Message = "Some Error Occured";
                    return View("Register");
                }
            }
            else
            {
                ViewBag.Message = "Invalid Details";
                return View("Register");
            }
        }
        private bool addUser(User user)
        {
            SqlConnection con=null;
            try
            {
                string constring = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\koush\\OneDrive\\Documents\\visual studio 2015\\Projects\\DatabaseConnWebApplication\\DatabaseConnWebApplication\\App_Data\\UserDatabase.mdf; Integrated Security = True";
                con = new SqlConnection(constring);
                con.Open();
                SqlCommand myCommand = new SqlCommand("INSERT INTO UserAccount Values('" + user.UserID + "','" + user.UserName + "','" + user.UserPassword + "');", con);
                myCommand.ExecuteNonQuery();
                return true;
            }
            catch(Exception)
            {
                return false;
            }
            finally
            {
                con.Close();
            }
        }
        private bool validatePwd(string pwd)
        {
            if(pwd.Length<6)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private bool validateID(string id)
        {
            if (id.Length < 6)
            {
                return false;
            }
            else
            {
                return true;
            }
        }        
        private bool validateName(string name)
        {
            if(!name.Equals(""))
            {
                foreach(char x in name.ToLower())
                {
                    if((int)x<97 || (int)x>122 )
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }
       
        public User searchUser(string id)
        {
            SqlConnection con = null;
            User user =  null;
            try
            {
                con = new SqlConnection("Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = C:\\Users\\koush\\OneDrive\\Documents\\visual studio 2015\\Projects\\DatabaseConnWebApplication\\DatabaseConnWebApplication\\App_Data\\UserDatabase.mdf; Integrated Security = True");
                SqlCommand cm = new SqlCommand("SELECT * FROM UserAccount WHERE UserId='" + id + "';", con);
                con.Open();
                SqlDataReader sdr = cm.ExecuteReader();
                while (sdr.Read())
                {
                    //Console.WriteLine(sdr["EmployeeID"] + " " + sdr["EmpName"] + " " + sdr["Designation"]);
                    user = new User(sdr["UserId"].ToString(), sdr["UserName"].ToString(), sdr["Password"].ToString());
                }
            }
            catch (Exception)
            {
                return user;
            }
            finally
            {
                con.Close();
            }

            return user;

        }
    }
}