﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DatabaseConnWebApplication.Models
{
    public class User
    {
        string userID, userName, userPassword;

        public User(string userID, string userName, string userPassword)
        {
            this.UserID = userID;
            this.UserName = userName;
            this.UserPassword = userPassword;
        }
        public User()
        {

        }

        public string UserID
        {
            get
            {
                return userID;
            }

            set
            {
                userID = value;
            }
        }

        public string UserName
        {
            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public string UserPassword
        {
            get
            {
                return userPassword;
            }

            set
            {
                userPassword = value;
            }
        }
    }
}