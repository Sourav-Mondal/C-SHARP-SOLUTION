using System;
using System.Collections;
using System.Collections.Generic;

class Employee
{

    public String EmployeeName { get; set; }
    public int EmployeeId { get; set; }
    public Double Salary { get; set; }

    public Employee(string _name, int _id, double s)
    {
        EmployeeName = _name;
        EmployeeId = _id;
        Salary = s;
    }
}

class EmployeeDAL
{
    List<Employee> Emp = new List<Employee>();
    Employee[] Employees = new Employee[100];
    String str;

    public bool AddEmployee(Employee e)
    {
        Emp.Add(e);
        return true;

    }
    public bool DeleteEmployee(int id)
    {
        foreach (var k in Emp)
        {

            if (k.EmployeeId == id)
            {
                Emp.Remove(k);
                break;
            }
        }
        return true;
    }
    public string SearchEmployee(int id)
    {

        foreach (var k in Emp)
        {

            if (k.EmployeeId == id)
            {
                str = k.EmployeeName + "  Salary: " + k.Salary.ToString();
                break;
            }
        }
        return str;
    }
    public Employee[] GetAllEmployeesistAll()
    {
        int j = 0;
        foreach (var o in Emp)
        {

            Employees[j] = o;
            j++;
        }
        return Employees;


    }

}
public class Program
{
    public static void Main(string[] args)
    {

        EmployeeDAL e2 = new EmployeeDAL();
        while (true)
        {
            Console.WriteLine("\t\tEmployee Manager\n\n1. Add Employee\n2. Delete Employee\n3. Search Employee\n4. View All employee");
            int v = int.Parse(Console.ReadLine());
            switch (v)
            {
                case 1:
                    {
                        Console.WriteLine("Enter Employee Name, ID and its salary");
                        string _name = Console.ReadLine();
                        int _id = int.Parse(Console.ReadLine());
                        double s = double.Parse(Console.ReadLine());
                        Employee e1 = new Employee(_name, _id, s);
                        e2.AddEmployee(e1);
                        break;
                    }
                case 2:
                    {
                        int n = int.Parse(Console.ReadLine());
                        e2.DeleteEmployee(n);
                        break;
                    }
                case 3:
                    {
                        int b = int.Parse(Console.ReadLine());
                        Console.WriteLine(e2.SearchEmployee(b));
                        break;
                    }
                case 4:
                    {
                        Employee[] ar = e2.GetAllEmployeesistAll();
                        int l = ar.Length;
                        for (int j = 0; j < l; j++)
                        {
                            if (ar[j] == null)
                            {
                                break;
                            }
                            Console.WriteLine("Name: {0}\nId: {1}\nSalary{2}", ar[j].EmployeeName, ar[j].EmployeeId, ar[j].Salary);
                        }
                        break;



                    }

            }
        }






    }
}

