/*Create a Program class to accept a string, containing multiple words with alphabets and digits.
  Each alphabet should be added to the AlphaList and each digit should be added to the DigitList.
 And sort both the lists.*/

using System;
using System.Collections.Generic;
 class program
{
    List<char> AlphaList=new List<char>();
    List<int> DigitList = new List<int>();
    public static void Main(string[]args)
    {
        string str;
        str = Console.ReadLine();
     
        program p1 = new program();
        foreach(char ch in str)
        {
            Char.ToLower(ch);
        
                if(Char.IsLetter(ch))
                {
                    p1.AlphaList.Add(Char.ToLower(ch));
                }
                if (Char.IsDigit(ch))
                {
                    p1.DigitList.Add(ch);
                }
        }
        p1.AlphaList.Sort();
        p1.DigitList.Sort();
        Console.Write("Sorted Alphalist:  ");

        foreach (char ch in p1.AlphaList)
        {
            Console.Write(ch+" ");

        }
        Console.Write("\n\nSorted Digitlist:  ");

        foreach (char k in p1.DigitList)
        {
            Console.Write(k + " ");

        }
        
    }
}
