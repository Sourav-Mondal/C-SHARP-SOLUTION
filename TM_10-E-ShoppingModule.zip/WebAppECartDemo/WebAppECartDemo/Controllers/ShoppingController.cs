﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAppECartDemo.ViewModel;
using WebAppECartDemo.Models;

namespace WebAppECartDemo.Controllers
{
    public class ShoppingController : Controller
    {
        // GET: Shopping
        private ECartDBEntities objECartDBEntities;
        private List<ShoppingCartModel> listofShoppingCartModels;
        public ShoppingController()
        {
            objECartDBEntities = new ECartDBEntities();
            listofShoppingCartModels = new List<ShoppingCartModel>();
        }
        public ActionResult Index()
        {
            IEnumerable<ShoppingViewModel> listofShoppingViewModel = (from objItem in objECartDBEntities.Items
                                                                      join
                             objCate in objECartDBEntities.Categories on objItem.CategoryId equals objCate.CategoryId
                                                                      select new ShoppingViewModel()
                                                                      {
                                                                          ImagePath = objItem.ImagePath,
                                                                          ItemName = objItem.ItemName,
                                                                          Description = objItem.Description,
                                                                          ItemPrice = objItem.ItemPrice,
                                                                          ItemId = objItem.ItemId,
                                                                          Category = objCate.CategoryName,
                                                                          ItemCode = objItem.ItemCode
                                                                      }
                                                                      ).ToList();
            return View(listofShoppingViewModel);
        }
        [HttpPost]
        public JsonResult Index( string ItemId)
        {
           
            ShoppingCartModel objShoppingCartModel = new ShoppingCartModel();
            Item objitem = objECartDBEntities.Items.Single(model => model.ItemId.ToString() == ItemId);
            if(Session["CartCounter"]!=null)
            {
                listofShoppingCartModels = Session["CartItem"] as List<ShoppingCartModel>;
            }
            if(listofShoppingCartModels.Any(model=>model.ItemId==ItemId))
            {
                objShoppingCartModel = listofShoppingCartModels.Single(model => model.ItemId.ToString() == ItemId);
                objShoppingCartModel.Quantity = objShoppingCartModel.Quantity = 1;
                objShoppingCartModel.Total = objShoppingCartModel.Quantity = objShoppingCartModel.UnitPrice;

            }
            else
            {
                objShoppingCartModel.ItemId = ItemId;
                objShoppingCartModel.ImagePath = objitem.ImagePath;
                objShoppingCartModel.ItemName = objitem.ItemName;
                objShoppingCartModel.Quantity = 1;
                objShoppingCartModel.Total = objitem.ItemPrice;
                objShoppingCartModel.UnitPrice = objitem.ItemPrice;
                listofShoppingCartModels.Add(objShoppingCartModel);





            }
            Session["CartCounter"] = listofShoppingCartModels.Count;
            Session["CartItem"] = listofShoppingCartModels;
            return Json(new { Success=true,counter=listofShoppingCartModels.Count}, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ShoppingCart()
        {
            listofShoppingCartModels = Session["CartItem"] as List<ShoppingCartModel>;
            return View(listofShoppingCartModels);
        }
        [HttpPost]

        public ActionResult AddOrder()
        {
            listofShoppingCartModels = Session["CartItem"] as List<ShoppingCartModel>;
            OrderModel orderobj = new OrderModel()
            {
                OrderDate = DateTime.Now,
                OrderNumber = string.Format("(0:ddmmyyyy)", DateTime.Now)
            };
            objECartDBEntities.Orders.Add(orderobj);
            objECartDBEntities.SaveChanges();
           OrderId = orderobj.OrderId;
            foreach(var item in listofShoppingCartModels)
            {

                OrderDetails objOrderDetails = new OrderDetails();
                objOrderDetails.Total = item.Total;
                objOrderDetails.ItemId = item.ItemId;
                objOrderDetails.OrderId = OrderId;
                objOrderDetails.Quantity = item.Quantity;
                objOrderDetails.UnitPrice = item.UnitPrice;
                objECartDBEntities.OrderDetails.Add(objOrderDetails);
                objECartDBEntities.SaveChanges();



            }
            Session["CartItem"] = null;
            Session["CartCounter"] = null;
            return RedirectToAction("Index");
        }
    }
}