﻿using System;
using System.Collections.Generic;
using System.Runtime.Versioning;
using VoterEntry.Util;
using VoterEntry.Exceptions;
using System.Globalization;

namespace VoterEntry
{
    class Voter
    {
        public string VoterID;
        public string FirstName;
        public string LastName;
        public string DateofBirth;
        public int Age;
        public string FathersName;
        public string Gender;
        public string Address;
        public string ConstituencyName;
        public Voter( string FirstName, string LastName, string DateofBirth, string FathersName, string Gender, string Address, string ConstituencyName)
        {
         
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.DateofBirth = DateofBirth;
          
            this.FathersName = FathersName;
            this.Gender = Gender;
            this.Address = Address;
            this.ConstituencyName = ConstituencyName;
        }

    }
    class VoterManagement
    {

        List<Voter> VoterList = new List<Voter>();
        VoterUtility vu = new VoterUtility();
        public string AddVoter(Voter obj)
        {

            //AgeExeption au = new AgeExeption();
            if (obj == null)
            {
                return "null";
            }
            else
            {
                if (obj.FirstName == null || obj.LastName == null || obj.DateofBirth == null || obj.FathersName == null || obj.Address == null ||
                    obj.Gender == null || obj.ConstituencyName == null)
                {
                    return "null";
                }
                else
                {
                    string doc = obj.DateofBirth;
                   
                    DateTime dol = Convert.ToDateTime(doc);
                    string su = vu.GenerateVoterID(obj.FirstName, obj.LastName, dol);
                    obj.VoterID = su;
                    int age = (DateTime.Now.Year - dol.Year);
                    try
                    {
                        if (age < 18)
                        {
                            throw (new AgeExeption("Age shouldnot be less than 18 \n retry and enter the valid age\n"));
                        }
                        else
                        {
                            obj.Age = age;
                            VoterList.Add(obj);
                            Console.WriteLine("Voter candidate are inserted into voterlist successful");

                        }
                    }
                    catch(AgeExeption e)
                    {
                        Console.WriteLine(e.Message);
                    }


                    
                }
            }

            return "true";

        }
        public bool ModifyVoter(Voter obj)
        {
            if (obj == null)
            {
                return false;
            }
            else
            {
                if (obj.FirstName == null || obj.LastName == null || obj.DateofBirth == null || obj.FathersName == null || obj.Address == null ||
                    obj.Gender == null || obj.ConstituencyName == null)
                {
                    return false;
                }
                else
                {

                    Console.WriteLine("enter the VoterId ");
                    string vi = Console.ReadLine();

                    Voter vt = VoterList.Find(vot => vot.VoterID == vi);
                    vt.FirstName = obj.FirstName;
                    vt.LastName = obj.LastName;
                    vt.DateofBirth = obj.DateofBirth;
                    vt.FathersName = obj.FathersName;
                    vt.Address = obj.Address;
                    vt.Gender = obj.Gender;
                    vt.ConstituencyName = obj.ConstituencyName;
                    string doc = obj.DateofBirth;
                    DateTime dol = Convert.ToDateTime(doc);
                    int age = (DateTime.Now.Year - dol.Year);
                    if (age < 18)
                    {
                        throw (new AgeExeption("Age shouldnot be less than 18"));
                    }
                    else
                    {
                        vt.Age = age;

                        Console.WriteLine("Voter candidate are updated into voterlist successful");

                    }
                }

            }
            return true;
        }
        public bool DeleteVoter(string strVoterID)
        {
            Voter vt = VoterList.Find(vot => vot.VoterID == strVoterID);
            if (vt == null)
            {
                return false;
            }
            else
            {
                VoterList.Remove(vt);
                Console.WriteLine("Voter candidate are deleted from voterlist successful");
            }
            return true;
        }
        public Voter SearchVoter(string strVoterID)
        {
            Voter vt = VoterList.Find(vot => vot.VoterID == strVoterID);
            if (vt != null)
            {
                Console.WriteLine("the details of voter of {0} is", strVoterID);

                Console.WriteLine("The voter first name is:{0}", vt.FirstName);
                Console.WriteLine("The voter last name is:{0}", vt.LastName);
                Console.WriteLine("The voter Gender is:{0}", vt.Gender);
                Console.WriteLine("The voter father name is:{0}", vt.FathersName);
                Console.WriteLine("The voter date of birth is:{0}", vt.DateofBirth);
                Console.WriteLine("The voter Address is:{0}", vt.Address);
                Console.WriteLine("The voter Age is:{0}", vt.Age);
                Console.WriteLine("The voter ConstituencyName  is:{0}", vt.ConstituencyName);
                Console.WriteLine("The voter VoterId is:{0}", vt.VoterID);


                return vt;
            }
            return null;
        }
        public List<Voter> GetVoterList()
        {
           
            foreach (Voter vi in VoterList)

            {
                
                Console.WriteLine("Firstname ->"+vi.FirstName + "   Lastname->" + vi.LastName + "  VoterId->" + vi.VoterID + "   DateofBirth->" + vi.DateofBirth +
                     "  FatherName->" + vi.FathersName + "  Age->" + vi.Age + "   Gender->"+ vi.Gender + "   Address->" + vi.Address + "   ConstituencyName->" + vi.ConstituencyName);
            }
            return VoterList;
        }

    }





    class Program
    {
       
        static void Main(string[] args)
        {
            VoterManagement vm = new VoterManagement();
            bool d = true;
            while (d)
            {
                Console.WriteLine("1.add Voter");
                Console.WriteLine("2.update Voter");
                Console.WriteLine("3.Delete Voter");
                Console.WriteLine("4.Search Voter");
                Console.WriteLine("5.show Volter List");
                Console.WriteLine("6.Exit");

                //Console.WriteLine("Enter your choice");
                Console.WriteLine("Enter your choice");
                int cho=int.Parse(Console.ReadLine());
                if(cho != 1 && cho != 2 && cho != 3&& cho != 4&& cho != 5 && cho != 6)
                {
                    Console.WriteLine("enter the valid choice");

                }
                else
                {
                    switch (cho)
                    {
                        case 1:
                            Console.WriteLine("enter the first name:");
                            string fname = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the last name:");
                            string lname = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the dob name:");
                            string dob = Console.ReadLine();
                            Console.WriteLine("enter the father name:");
                            string faname = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the gender name:");
                            string gen = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the address name:");
                            string address = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the constinuency name:");
                            string consname = (Console.ReadLine()).ToUpper();
                            vm.AddVoter(new Voter(fname, lname, dob, faname, gen, address, consname));
                            break;
                        case 2:
                            Console.WriteLine("enter the first name:");
                            string upfname = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the last name:");
                            string uplname = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the dob name:");
                            string updob = Console.ReadLine();
                            Console.WriteLine("enter the father name:");
                            string upfaname = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the gender name:");
                            string upgen = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the address name:");
                            string upaddress = (Console.ReadLine()).ToUpper();
                            Console.WriteLine("enter the constinuency name:");
                            string upconsname = (Console.ReadLine()).ToUpper();
                            vm.ModifyVoter(new Voter(upfname, uplname, updob, upfaname, upgen, upaddress, upconsname));
                            break;
                        case 3:
                            Console.WriteLine("enter the voterid:");
                            string votid = Console.ReadLine();
                            vm.DeleteVoter(votid);
                            break;
                        case 4:
                            Console.WriteLine("enter the voterid:");
                            string svotid = Console.ReadLine();
                            vm.SearchVoter(svotid);
                            break;
                        case 5:

                            vm.GetVoterList();
                            break;
                        case 6:
                            Console.WriteLine("Exitng");
                            d = false;
                            break;


                    }
                }
               
            }
            
        }
        

    }
    
}
