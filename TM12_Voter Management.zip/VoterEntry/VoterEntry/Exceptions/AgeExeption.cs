﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoterEntry.Exceptions
{
    class AgeExeption : Exception
    {
        public AgeExeption(string strMessage) : base(strMessage)
        {

        }
    }
}
