﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VoterEntry.Util
{
    class VoterUtility
    {
        public string GenerateVoterID(string strFName, string strLName, DateTime dtDateofBirth)
        {


            string VoterID = "";
            //dtoDateofBirth =DateTime.ParseExact()
            string strFirstName= strFName.ToUpper();
            string strLastName = strLName.ToUpper();
            int lenoffirstname = strFirstName.Length;
            string lenoffirstnamest = lenoffirstname.ToString();
            int lenoflastname = strLastName.Length;
            string lenoflastnamest = lenoflastname.ToString();
            VoterID = VoterID + strFirstName[0] + strLastName[0];
            string newdtDateofBirth = dtDateofBirth.ToString();
            
            int lenofnewdtDateofBirth = newdtDateofBirth.Length;
            string monthofdtDateofBirthst = newdtDateofBirth.Substring(0, 2);
            string dateofdtDateofBirthst  = newdtDateofBirth.Substring(3, 2);
            string yearofdtDateofBirthst = newdtDateofBirth.Substring(6, 4);

            int monthofdtDateofBirthint = Convert.ToInt32(dateofdtDateofBirthst);
            int  dateofdtDateofBirthint = Convert.ToInt32(monthofdtDateofBirthst);
            int yearofdtDateofBirthint = Convert.ToInt32(yearofdtDateofBirthst);
            int sum1 = 0;
            while (monthofdtDateofBirthint != 0)
            {
                int rem1 = monthofdtDateofBirthint % 10;
                sum1 += rem1;
                monthofdtDateofBirthint = monthofdtDateofBirthint / 10;
            }
            char lastletterofvoterId = VoterID[1];
            string sum1st = sum1.ToString();

            lastletterofvoterId = (char)(lastletterofvoterId - sum1);
            VoterID += lastletterofvoterId + lenoffirstnamest + lenoflastnamest + sum1st;
            int sum = 0;
            while (dateofdtDateofBirthint != 0)
            {
                int rem = dateofdtDateofBirthint % 10;
                sum += rem;
                dateofdtDateofBirthint = dateofdtDateofBirthint / 10;
            }
            string sumst = sum.ToString();

            int sum2 = 0;
            while (yearofdtDateofBirthint != 0)
            {
                int rem2 = yearofdtDateofBirthint % 10;
                sum2 += rem2;
                yearofdtDateofBirthint = yearofdtDateofBirthint / 10;
            }
            string sum2st = sum2.ToString();
            VoterID += sumst + sum2st;
            //VoterID += sum1st;
            //Console.WriteLine(VoterID);
            return VoterID;

        }
    }
}
