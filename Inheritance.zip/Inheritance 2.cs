using System;
public class Person
{
  public String f_name, l_name, e_add;
  public readonly String s_name = "xyz288";
  public DateTime dob = new DateTime ();
  DateTime Now = DateTime.Now;
  public bool ad, bd;
  public string returnString;
  public Person ()
  {
    f_name = Console.ReadLine ();
    l_name = Console.ReadLine ();
    e_add = Console.ReadLine ();
    dob = DateTime.Parse (Console.ReadLine ());
    DateTime today = DateTime.Now;
    if (dob == today)
      {
	bd = true;
      }
    else
      {
	bd = false;
      }
    int Years = new DateTime (DateTime.Now.Subtract (dob).Ticks).Year - 1;
    if (Years >= 18)
      {
	ad = true;
      }
    else
      {
	ad = false;
      }

    string[]dateAndMonth = dob.ToLongDateString ().Split (new char[]
							  {
							  ','});
    string[]ckhString = dateAndMonth[1].ToString ().Split (new char[]
							   {
							   ' '});
    if (ckhString[1].ToString () == "March")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 20)
	  {
	    returnString = "Pisces";
	  }
	else
	  {
	    returnString = "Aries";
	  }
      }
    else if (ckhString[1].ToString () == "April")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 19)
	  {
	    returnString = "Aries";
	  }
	else
	  {
	    returnString = "Taurus";
	  }
      }
    else if (ckhString[1].ToString () == "May")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 20)
	  {
	    returnString = "Taurus";
	  }
	else
	  {
	    returnString = "Gemini";
	  }
      }
    else if (ckhString[1].ToString () == "June")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 20)
	  {
	    returnString = "Gemini";
	  }
	else
	  {
	    returnString = "Cancer";
	  }
      }
    else if (ckhString[1].ToString () == "July")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 22)
	  {
	    returnString = "Cancer";
	  }
	else
	  {
	    returnString = "Leo";
	  }
      }
    else if (ckhString[1].ToString () == "August")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 22)
	  {
	    returnString = "Leo";
	  }
	else
	  {
	    returnString = "Virgo";
	  }
      }
    else if (ckhString[1].ToString () == "September")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 22)
	  {
	    returnString = "Virgo";
	  }
	else
	  {
	    returnString = "Libra";
	  }
      }
    else if (ckhString[1].ToString () == "October")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 22)
	  {
	    returnString = "Libra";
	  }
	else
	  {
	    returnString = "Scorpio";
	  }
      }
    else if (ckhString[1].ToString () == "November")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 21)
	  {
	    returnString = "Scorpio";
	  }
	else
	  {
	    returnString = "Sagittarius";
	  }
      }
    else if (ckhString[1].ToString () == "December")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 21)
	  {
	    returnString = "Sagittarius";
	  }
	else
	  {
	    returnString = "Capricorn";
	  }
      }
    else if (ckhString[1].ToString () == "January")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 19)
	  {
	    returnString = "Capricorn";
	  }
	else
	  {
	    returnString = "Aquarius";
	  }
      }
    else if (ckhString[1].ToString () == "February")
      {
	if (Convert.ToInt32 (ckhString[2]) <= 18)
	  {
	    returnString = "Aquarius";
	  }
	else
	  {
	    returnString = "Pisces";
	  }
      }
  }
  public string Star
  {

    get
    {
      return returnString;
    }

  }
  public bool Birthday
  {
    get
    {
      return bd;
    }
  }
  public bool Adult
  {
    get
    {
      return ad;
    }
  }

}
public class Employee:Person
{
  double sal;

  static void Main ()
  {
      
    Employee emp = new Employee ();
    HourlyEmployee he=new HourlyEmployee();
    PermanentEmployee pe=new PermanentEmployee();
      Console.WriteLine ("First Name: " + emp.f_name);
      Console.WriteLine ("Last Name: " + emp.l_name);
      Console.WriteLine ("Email Address: " + emp.e_add);
      Console.WriteLine ("DOB" + emp.dob);
      Console.WriteLine ("Is it your birthday? " + emp.Birthday);
      Console.WriteLine ("Are you an adult? " + emp.Adult);
      Console.WriteLine ("Star Sign: " + emp.Star);
      Console.WriteLine ("Screen Name" + emp.s_name);
  }
}
public class HourlyEmployee:Person
{
    double HoursWorked,PayPerHour;
    
}
public class PermanentEmployee:Person
{
    double hra,da,tax,NetPay,TotalPay;
}