﻿	using System;
	using System.Numerics;
	using System.Collections.Generic;
	class MyClass
{
	static void Main(string[] args)
    {
         int n = Convert.ToInt32(Console.ReadLine());
        
  while (n > 0)
        {
             string m = Console.ReadLine();
            
 string s1 = m.Split()[0];
             string s2 = m.Split()[1];
             string s3 = m.Split()[2];
             int StartingIndex = Convert.ToInt32(s2);
             int EndingIndex = Convert.ToInt32(s3);
             string a = s1.Substring(0, StartingIndex);
            
 int l;
            l = EndingIndex + 1 - StartingIndex;
             string b = s1.Substring(StartingIndex, l);
             char[] cha = b.ToCharArray();
            Array.Sort(cha);
            Array.Reverse(cha);
             string c = s1.Substring(EndingIndex + 1);
            Console.WriteLine(a + new string(cha) + c);
            n--;
            }
         }
	}

