﻿using System;

namespace Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
           

        }
    }
}
