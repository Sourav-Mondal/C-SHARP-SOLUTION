﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise1
{
   public class Student
    {
        public int StudentId { get; set; }
        public String Name { get; set; }

    }
}
