﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise1
{
    public class Course
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; }
    }
}
