﻿using System;
using System.Collections.Generic;

namespace Exercise2.Models
{
    public partial class Department
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }
        public string Location { get; set; }
    }
}
