﻿using System;
using System.Collections.Generic;

namespace Exercise2.Models
{
    public partial class CategorySalesFor1997
    {
        public string CategoryName { get; set; }
        public decimal? CategorySales { get; set; }
    }
}
