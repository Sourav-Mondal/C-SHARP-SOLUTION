using System; 
using System.Collections; 
using System.Collections.Generic; 
public class Employee
{
    public string e_name;
    public int e_id;
    public double sal;
    int count=0;
    public Employee(int e_id,string e_name,double sal)
    {
        this.e_name=e_name;
        this.e_id=e_id;
        this.sal=sal;
        count++;
    }

}
public class EmployeeDAL
{
    
    ArrayList myList = new ArrayList(); 
    public void AddEmployee(Employee e)
    {
      myList.Add(e);
        
    }
    public static void Main()
    {
        EmployeeDAL e= new EmployeeDAL();
Employee e1 = new Employee(1, "SaiRam ", 18000);
Employee e2 = new Employee(2, "Anu ",45677);
Employee e3 = new Employee(3, "Vasu ",78787);
Employee e4 = new Employee(4, "Shillu ", 76876);
Employee e5 = new Employee(5, "Madhu ", 79079);
Employee e6 = new Employee(6, "Volga ", 13444);
e.AddEmployee(e1);
e.AddEmployee(e2);
e.AddEmployee(e3);
e.AddEmployee(e4);
e.AddEmployee(e5);
Console.WriteLine("Name: "+e1.e_name+"ID: "+e1.e_id+"Salary: "+e1.sal);
Console.WriteLine("Name: "+e2.e_name+"ID: "+e2.e_id+"Salary: "+e2.sal);
Console.WriteLine("Name: "+e3.e_name+"ID: "+e3.e_id+"Salary: "+e3.sal);
Console.WriteLine("Name: "+e4.e_name+"ID: "+e4.e_id+"Salary: "+e4.sal);
Console.WriteLine("Name: "+e5.e_name+"ID: "+e5.e_id+"Salary: "+e5.sal);
}




}