using System;
using System.Collections;
class Program
{
  static void Main ()
  {

    SortedList sl = new SortedList ();

      sl.Add ("Ford", 1876);
      sl.Add ("Suzuki", 1976);
      sl.Add ("Ferrari", 1866);
      sl.Add ("Toyota", 1756);
      sl.Add ("Benz", 1876);
    ICollection key = sl.Keys;

      foreach (var k in key)
    {
      Console.WriteLine (k + ": " + sl[k]);
    }
  }
}
