﻿using System;

namespace BookAuthorManagement
{
    class Program
    {
        static int Menu()
        {
            Console.WriteLine("\n\n                   Book Author Details\n\n");
            Console.WriteLine("1. Add Book. \n2.Search Book.\n3.Update Book.\n4.View All Books.\n5.View all authors.\n6.Exit \n\nPlease enter your choice:: ");
            int data = Convert.ToInt32(Console.ReadLine());
            return data;
        }
        static void Main(string[] args)
        {
            int Option = 0;
            BookManagement.PreloadedData(5); // For Sample book Which are preloaded
            while(Option != 6)
            {
                Option = Menu();
                switch(Option)
                {
                    case 1: BookManagement.AddBook();
                        break;
                    case 2: BookManagement.SearchBook();
                        break;
                    case 3: BookManagement.UpdateBookDetails();
                        break;
                    case 4: BookManagement.ViewBooks();
                        break;
                    case 5: BookManagement.ViewAuthors();
                        break;
                    default:break; 
                }

            }

        }
    }
}
