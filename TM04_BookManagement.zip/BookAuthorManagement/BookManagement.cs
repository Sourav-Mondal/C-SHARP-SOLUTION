﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookAuthorManagement
{
    class BookManagement
    {
        static Book[] Rack = new Book[10];
        static int count = 5;
        public static void AddBook()
        {
            if (count < 10)
            {
                Console.WriteLine("Please Enter the Book ISBN");
                string _isbn = Console.ReadLine();
                Console.WriteLine("Enter the Book Title");
                string _bookname = Console.ReadLine();
                Console.WriteLine("Enter the Year of book published");
                int _year = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Price of the book ");
                double _price = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter the Author Name");
                string _authorname = Console.ReadLine();
                Console.WriteLine("Enter the Author Email");
                string _authoremail = Console.ReadLine();
                Console.WriteLine("Enter the Author Gender (M or F or N)");
                char _authorgender = Convert.ToChar(Console.ReadLine());

                Rack[count] = new Book(_isbn, _bookname, _year, _price, _authorname, _authoremail, _authorgender);
                count++;
            }
            else
                Console.WriteLine("Rack is filled.Can’t add more books");
        }
        public static void PreloadedData(int Key)
        {
            count = Key;
            Rack[0] = new Book("0916356639", "Vedanta: Voice of Freedom", 2020, 243.00, "Swami Vivekananda", "NONE", 'M');
            Rack[1] = new Book("8129142146", "One Indian Girl", 2016, 174.69, "Chetan Bhagat", "Chetan_Bhagat@gmail.com", 'M');
            Rack[2] = new Book("0007268335", "The God of Small Things", 2008, 99.59, "Arundhati Roy", "Arundhati_Roy@gmail.com", 'F');
            Rack[3] = new Book("0143450832", "Death - An Inside Story", 2020, 188.33, "Sadhguru", "Sadhguru@gmail.com", 'M');
            Rack[4] = new Book("8175994312", "Sherlock Holmes", 2017, 125.73, "Conan Doyle", "ConanDoyle@gmail.com", 'M');
        }
        public static void SearchBook()
        {
            Console.WriteLine("Enter the ISBN code of the Book you want to search");
            string id = Console.ReadLine();
            int temp = 0;
            for(int i = 0;i < 5;i++)
            {
                if(id == Rack[i].ISBN)
                {
                    temp++;
                    break;
                }
            }
            if(temp == 1)
            {
                Console.WriteLine("True");
            }
            else
                Console.WriteLine("False");
        }
        public static void ViewBooks()
        {
            for(int i = 0;i<count; i++)
            {
                Rack[i].DisplayBookDetails();
            }
        }
        public static void ViewAuthors()
        {
            for (int i = 0; i < count; i++)
            {
                Rack[i].AuthorDetails.DisplayAuthorDetails();
            }
        }
        public static void UpdateBookDetails()
        {
            Console.WriteLine("Enter the ISBN code of the Book you want to Update");
            string id = Console.ReadLine();
            int temp = 0,i;
            for (i = 0; i < 5; i++)
            {
                if (id == Rack[i].ISBN)
                {
                    temp++;
                    break;
                }
            }
            if (temp == 1)
            {
                int j = 0;
                while (j != 8)
                {
                    Console.WriteLine("Select the option which you want to Update");
                    Console.WriteLine("1.ISBN Code \n2.Book Name \n3.Year of published \n4.Price \n5.Author Name \n6.Author Email id \n7.Author Gender \n8.Exit");
                    j = Convert.ToInt32(Console.ReadLine());
                    if (j == 1)
                    {
                        Console.WriteLine("Please Enter the Book ISBN");
                        Rack[i].ISBN = Console.ReadLine();
                    }
                    else if (j == 2)
                    {
                        Console.WriteLine("Enter the Book Title");
                        Rack[i].BookName = Console.ReadLine();
                    }
                    else if (j == 3)
                    {
                        Console.WriteLine("Enter the Year of book published");
                        Rack[i].YearPublished = Convert.ToInt32(Console.ReadLine());
                    }
                    else if (j == 4)
                    {
                        Console.WriteLine("Enter the Price of the book ");
                        Rack[i].Price = Convert.ToDouble(Console.ReadLine());
                    }
                    else if (j == 5)
                    {
                        Console.WriteLine("Enter the Author Name");
                        Rack[i].AuthorDetails.AuthorName = Console.ReadLine();
                    }
                    else if (j == 6)
                    {
                        Console.WriteLine("Enter the Author Email");
                        Rack[i].AuthorDetails.AuthorEMail = Console.ReadLine();
                    }
                    else if (j == 7)
                    {
                        Console.WriteLine("Enter the Author Gender (M or F or N)");
                        Rack[i].AuthorDetails.Gender = Convert.ToChar(Console.ReadLine());
                    }
                }
            }
            else
                Console.WriteLine("Book Not Found");
        }

    }
}
