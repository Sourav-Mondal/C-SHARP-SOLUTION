﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookAuthorManagement
{
    class Book
    {
        public string ISBN;
        public string BookName;
        public int YearPublished;
        public double Price;
        public Author AuthorDetails;
        public Book (String _isbn , string _bookname ,int _year , double _price , string _name ,string _email ,char _gender)
        {
            ISBN = _isbn;
            BookName = _bookname;
            YearPublished = _year;
            Price = _price;
            AuthorDetails = new Author(_name , _email , _gender) ;
        }
        public void DisplayBookDetails()
        {
            Console.WriteLine("\nBook ISBN code   : {0}",ISBN);
            Console.WriteLine("  Book Title     : {0}", BookName);
            Console.WriteLine("Year of Published: {0}", YearPublished);
            Console.WriteLine("      Price      : {0}",Price);
        }
    }
}
