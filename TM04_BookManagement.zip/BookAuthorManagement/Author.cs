﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookAuthorManagement
{
    class Author
    {
        public string AuthorName;
        public string AuthorEMail;
        public char Gender;
        public Author(string name , string email , char gender)
        {
            AuthorName = name;
            AuthorEMail = email;
            Gender = gender;
        }
        public void DisplayAuthorDetails()
        {
            Console.WriteLine("\nName of the Author is {0}",AuthorName);
            Console.WriteLine("Email id : {0}",AuthorEMail);
            Console.WriteLine("Gender   : {0}",Gender);
        }
    }
}
