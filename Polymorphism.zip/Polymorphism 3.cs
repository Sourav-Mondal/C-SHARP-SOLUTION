using System;
class Math
{
  public int add (int a, int b)
  {
    return a + b;
  }
  public int add (int a, int b, int c)
  {
    return a + b + c;
  }
  public int sub (int a, int b)
  {
    return a - b;
  }
  public int sub (int a, int b, int c)
  {
    return (a - b) - c;
  }
  public int mul (int a, int b)
  {
    return a * b;
  }
  public int mul (int a, int b, int c)
  {
    return a * b * c;
  }
  public int div (int a, int b)
  {
    return a / b;
  }
  public int div (int a, int b, int c)
  {
    return (a / b) / c;
  }

}

class program
{
  static void Main ()
  {
    Math m = new Math ();
    int a = m.add (10, 5);
    int b = m.add (10, 5, 1);
    int c = m.sub (10, 5);
    int d = m.sub (10, 5, 1);
    int e = m.mul (10, 5);
    int f = m.mul (10, 5, 1);
    double g = m.div (10, 5);
    double h = m.div (10, 5, 1);
      Console.WriteLine ("Sum of two numbers is: " + a);
      Console.WriteLine ("Sum of three numbers is: " + b);
      Console.WriteLine ("Difference between two numbers is: " + c);
      Console.WriteLine ("Difference between three numbers is: " + d);
      Console.WriteLine ("Product of two numbers is: " + e);
      Console.WriteLine ("Product of three numbers is: " + f);
      Console.WriteLine ("Quotient of two numbers is: " + g);
      Console.WriteLine ("Quotient of three numbers is: " + h);

  }
}
