using System;
class Math
{
  public void area (double radius)
  {
    Console.WriteLine ("The area of the circle is: " +
		       (3.14 * radius * radius) + "sq.units");
  }
  public void area (int length, int breadth)
  {
    Console.WriteLine ("The area of the rectangle is: " + (length * breadth) +
		       "sq.units");
  }
  public void area (double bas, double height)
  {
    Console.WriteLine ("The area of the triangle is: " +
		       (0.5 * bas * height) + "sq.units");
  }
}

class program
{
  static void Main ()
  {
    Math m = new Math ();
      m.area (5.89);
      m.area (3.4, 3.7);
      m.area (6, 7);

  }
}
