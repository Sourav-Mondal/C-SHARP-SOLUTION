using System;
public class SuperDuck
{
  public virtual void eat ()
  {

  }
}
public class MyDuck:SuperDuck
{
  public override void eat ()
  {
    Console.WriteLine ("I am eating food...");
  }
}
public class ToyDuck:SuperDuck
{
  public override void eat ()
  {
    Console.WriteLine ("My food is electrons...");
  }
}
class Duck
{
  static void Main ()
  {
    int ch;
    SuperDuck sd = new SuperDuck ();
    MyDuck md = new MyDuck ();
    ToyDuck td = new ToyDuck ();
      Console.WriteLine ("1. Press 1 for Feeding your Duck");
      Console.WriteLine ("2. Press 2 for feeding the Toy duck");
      ch = Convert.ToInt32 (Console.ReadLine ());
    switch (ch)
      {
      case 1: md.eat ();
	    break;
	  case 2:td.eat ();
	    break;
	  default:Console.WriteLine ("Incorrect Choice!");
	    break;
      }
  }
}
