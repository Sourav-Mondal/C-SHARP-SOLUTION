using System;
public class Fruit
{
  public string name, taste, size;
  public virtual void eat ()
  {
    Console.WriteLine ("Name of the friut is displayed");
    Console.WriteLine ("Taste will be displayed");

  }

}
public class Apple:Fruit
{

  public override void eat ()
  {
    Console.WriteLine ("Name of the friut is Apple");
    Console.WriteLine ("It tastes Sweet");
  }
}
public class Orange:Fruit
{

  public override void eat ()
  {
    Console.WriteLine ("Name of the friut is Orange");
    Console.WriteLine ("It tastes Sour");
  }
}
class program
{
  static void Main ()
  {
    Fruit f = new Fruit ();
    Apple a = new Apple ();
    Orange o = new Orange ();
      f.eat ();
      a.eat ();
      o.eat ();
  }
}
