using System;
class mark
{

  static void Main ()
  {
    int eng;
    int sci;
    int math;
      Console.WriteLine ("Enter name:");
    string name = Console.ReadLine ();
      Console.WriteLine ("Enter English marks:");
      try
    {
      eng = Convert.ToInt32 (Console.ReadLine ());
    }
    catch (FormatException)
    {
      Console.WriteLine ("The entered mark is not an integer");

    }
    Console.WriteLine ("Enter Math marks:");
    try
    {
      math = Convert.ToInt32 (Console.ReadLine ());
    }
    catch (FormatException)
    {
      Console.WriteLine ("The entered mark is not an integer");

    }
    Console.WriteLine ("Enter Science marks:");
    try
    {
      sci = Convert.ToInt32 (Console.ReadLine ());
    }
    catch (FormatException)
    {
      Console.WriteLine ("The entered mark is not an integer");

    }

  }

}
