/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class mark
{


  static void Main ()
  {



    int eng;
    int sci;
    int math;
      Console.WriteLine ("Enter name:");
    string name = Console.ReadLine ();
      Console.WriteLine ("Enter English marks:");
      try
    {
      eng = Convert.ToInt32 (Console.ReadLine ());
      if (eng < 0)
	{
	  NegativeNumberException M =
	    new NegativeNumberException ("Negative number is entered!");
	    try
	  {
	    throw M;
	  }
	  catch (Exception e)
	  {
	    Console.WriteLine (e.Message);
	  }

	}
    }
    catch (FormatException)
    {
      Console.WriteLine ("The entered mark is not an integer");

    }


    Console.WriteLine ("Enter Math marks:");
    try
    {
      math = Convert.ToInt32 (Console.ReadLine ());
      if (math < 0)
	{
	  NegativeNumberException M =
	    new NegativeNumberException ("Negative number is entered!");
	  try
	  {
	    throw M;
	  }
	  catch (Exception e)
	  {
	    Console.WriteLine (e.Message);
	  }

	}
    }
    catch (FormatException)
    {
      Console.WriteLine ("The entered mark is not an integer");

    }
    Console.WriteLine ("Enter Science marks:");
    try
    {
      sci = Convert.ToInt32 (Console.ReadLine ());
      if (sci < 0)
	{
	  NegativeNumberException M =
	    new NegativeNumberException ("Negative number is entered!");
	  try
	  {
	    throw M;
	  }
	  catch (Exception e)
	  {
	    Console.WriteLine (e.Message);
	  }

	}
    }
    catch (FormatException)
    {
      Console.WriteLine ("The entered mark is not an integer");

    }

  }

}

class NegativeNumberException:Exception
{

  public NegativeNumberException (string str)
  {
    Console.WriteLine (str);
  }
}
