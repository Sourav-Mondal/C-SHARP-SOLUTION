﻿using System;
class Exercise1
{
    static void Main(string[] args)
    {
        int x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Area of Square is: {0}", x * x);
        Console.ReadKey();
    }
}

