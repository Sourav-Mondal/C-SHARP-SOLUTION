﻿using System;
class Excercise5
{
    static void Main(string[] args)
    {
        string s ="phani", s2;
        char temp;
        char[] s1 = s.ToCharArray();
        int i = 0, j = s.Length - 1;
        //string reverse
        while (i < j)
        {
            temp = s1[i];
            s1[i] = s1[j];
            s1[j] = temp;
            i++;
            j--;
        }
        Console.WriteLine("after reversing");
        Console.WriteLine(s1);
        // Extract part of the string from 2nd position till the end of the string
        Console.WriteLine("after extracting from 2nd pos to till end");
        for (i = s.Length - 3; i >= 0; i--)
            Console.Write(s1[i]); Console.WriteLine();
        //Replace any given character by '$' and print the new string
        Array.Reverse(s1);
        char key;
        Console.WriteLine("enter a key");
        key = Console.ReadLine()[0];
        for (i = 0; i < s.Length; i++)
        {
            if (s1[i] == key)
            {
                s1[i] = '$';
            }
        }
        Console.WriteLine("Aftrer replacing");
        Console.WriteLine(s1);
        //Copy the string to another string variable, Modify the data in 2nd string variable and print both the strings
        Console.WriteLine("after modifying 2nd string");
        s2 = s;
        s2 += s;
        Console.WriteLine("s1: "+s);
        Console.WriteLine("s2: "+s2);
        Console.ReadKey();
    }
}
