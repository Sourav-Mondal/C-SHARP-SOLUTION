﻿using System;
namespace Exercise2
{
    class Excercise2
    {
        static void Main(string[] args)
        {
            string s;
            int digitCount = 0, alphaCount = 0;
            s = Console.ReadLine();
            char[] s1 = s.ToCharArray();
            for(int i=0;i<s.Length;i++)
            {
                if(s1[i]>='A'&&s1[i]<='Z'|| s1[i] >= 'a' && s1[i] <= 'z')
                {
                    alphaCount++;
                }
                else if(s[i] >= '1' && s1[i] <= '9')
                {
                    digitCount++;
                }
            }
            Console.WriteLine("DigitCount and AlphabetCount is: {0} and {1}", digitCount, alphaCount);
            Console.ReadKey();
        }
    }
}
