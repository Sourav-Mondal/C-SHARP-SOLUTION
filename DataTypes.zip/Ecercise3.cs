﻿using System;
    class Excercise3
    {
        static void Main(string[] args)
        {
        string s;
            s = Console.ReadLine();
            char[] s1 = s.ToCharArray();
            for (int i = 0; i < s.Length; i++)
            {
                Console.Write(" " + ++s1[i]);
            }
            Console.ReadKey();
        }
    }
