﻿using System;
    class Excercise4
    {
        static void Main(string[] args)
        {
            string s;
            s = Console.ReadLine();
            char[] s1 = s.ToCharArray();
            for (int i = 0; i < s.Length; i++)
            {
                if (s1[i] >= 'A' && s1[i] <= 'Z')
                {
                    s1[i] = (char) (s1[i] + 'a'-'A');
                }
                else if(s1[i] >= 'a' && s1[i] <= 'z')
                {
                    s1[i] =(char) (s1[i]+'A'-'a');
                }
            }
        string s2 = new string(s1);
        Console.WriteLine("After Toggling: {0}", s2);
            Console.ReadKey();
        }
    }
