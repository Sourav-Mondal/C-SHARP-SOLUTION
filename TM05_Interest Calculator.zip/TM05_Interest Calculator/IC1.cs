using System;
interface Account
{
    void CalculateInterest();
}
abstract class FD : Account
{
    public abstract void CalculateInterest();

}
class FDAccount : FD
{
    public double Interest_rate { get; set; }
    public double Amount { get; set; }
    public int No_of_days { get; set; }
    public int Age { get; set; }
    public FDAccount(double _amn, int _day, int m)
    {
        Amount = _amn;
        No_of_days = _day;
        Age = m;

    }

    public override void CalculateInterest()
    {
        if (Amount < 10000000)
        {
            if (Age <= 50)
            {
                if (No_of_days > 7 && No_of_days < 15)
                {
                    Interest_rate = 4.5;
                }
                else if (No_of_days >= 15 && No_of_days < 30)
                {
                    Interest_rate = 4.75;
                }
                else if (No_of_days >= 30 && No_of_days < 46)
                {
                    Interest_rate = 5.5;
                }
                else if (No_of_days > 45 && No_of_days <= 60)
                {
                    Interest_rate = 7;
                }
                else if (No_of_days > 60 && No_of_days <= 184)
                {
                    Interest_rate = 7.5;
                }
                else if (No_of_days > 184 && No_of_days <= 365)
                {
                    Interest_rate = 8;
                }

            }
            else
            {
                if (No_of_days > 7 && No_of_days < 15)
                {
                    Interest_rate = 5;
                }
                else if (No_of_days >= 15 && No_of_days < 30)
                {
                    Interest_rate = 5.25;
                }
                else if (No_of_days >= 30 && No_of_days < 46)
                {
                    Interest_rate = 6;
                }
                else if (No_of_days > 45 && No_of_days <= 60)
                {
                    Interest_rate = 7.5;
                }
                else if (No_of_days > 60 && No_of_days <= 184)
                {
                    Interest_rate = 8;
                }
                else if (No_of_days > 184 && No_of_days <= 365)
                {
                    Interest_rate = 8.5;
                }

            }
        }
        else
        {
            if (No_of_days > 7 && No_of_days < 15)
            {
                Interest_rate = 6.5;
            }
            else if (No_of_days >= 15 && No_of_days < 30)
            {
                Interest_rate = 6.75;
            }
            else if (No_of_days >= 30 && No_of_days < 46)
            {
                Interest_rate = 6.75;
            }
            else if (No_of_days > 45 && No_of_days <= 60)
            {
                Interest_rate = 8;
            }
            else if (No_of_days > 60 && No_of_days <= 184)
            {
                Interest_rate = 8.5;
            }
            else if (No_of_days > 184 && No_of_days <= 365)
            {
                Interest_rate = 10;
            }

        }
        double i = (Interest_rate / 100) * Amount;
        Console.WriteLine("Interest gained is: {0}", i);

    }

}
abstract class SB : Account
{
    public abstract void CalculateInterest();

}
class SBAccount : SB
{
    public double Interest_rate { get; set; }
    public double Amount { get; set; }
    public SBAccount(double _amount)
    {
        Amount = _amount;
        Interest_rate = .04;
    }
    public override void CalculateInterest()
    {
        double k = Amount * Interest_rate;
        Console.WriteLine("Interest gained is: {0}", k);
    }


}
abstract class RD : Account
{
    public abstract void CalculateInterest();

}
class RDAccount : RD
{
    public double Interest_rate { get; set; }
    public double Amount { get; set; }
    public RDAccount(double _amn)
    {
        Amount = _amn;
    }
    public override void CalculateInterest()
    {
        Console.WriteLine("Enter no. of months and Age: ");
        int d = int.Parse(Console.ReadLine());
        int a = int.Parse(Console.ReadLine());
        if (a <= 50)
        {
            if (d <= 6)
            {
                Interest_rate = 7.5;
            }
            else if (d <= 9)
            {
                Interest_rate = 7.75;
            }
            else if (d <= 12)
            {
                Interest_rate = 8;
            }
            else if (d <= 15)
            {
                Interest_rate = 8.25;
            }
            else if (d <= 18)
            {
                Interest_rate = 8.5;
            }
            else if (d <= 21)
            {
                Interest_rate = 8.75;
            }
        }
        else
        {
            if (d <= 6)
            {
                Interest_rate = 8;
            }
            else if (d <= 9)
            {
                Interest_rate = 8.25;
            }
            else if (d <= 12)
            {
                Interest_rate = 8.5;
            }
            else if (d <= 15)
            {
                Interest_rate = 8.75;
            }
            else if (d <= 18)
            {
                Interest_rate = 9;
            }
            else if (d <= 21)
            {
                Interest_rate = 9.25;
            }
        }
        double i = (Interest_rate / 100) * Amount;
        Console.WriteLine("Interest gained is: {0}", i);
    }


}
class NegativeNumberException : Exception
{
    public NegativeNumberException()
    {

    }
    public NegativeNumberException(int n) : base(String.Format("Invalid Number: {0}", n))
    {

    }

}
class Interest
{
    public static void ValidateNumber(params double[] arr)
    {
        foreach (int k in arr)
        {
            if (k < 0)
            {
                throw new NegativeNumberException(k);
            }

        }
    }
    public static void Main(string[] args)
    {
        int j = 0;
        while (j != 4)
        {
            Console.WriteLine("Select the option :");
            Console.WriteLine("1. Interest Calculator-SB\n2. Interest Calculator-FD\n3. Interest Calculator-RD\n4. Exit.");
            int n = int.Parse(Console.ReadLine());


            switch (n)
            {
                case 1:
                    {
                        try
                        {
                            Console.WriteLine("Enter the average amount in your account:");
                            double _amount = double.Parse(Console.ReadLine());
                            ValidateNumber(_amount);
                            SBAccount s = new SBAccount(_amount);
                            s.CalculateInterest();
                        }
                        catch (NegativeNumberException ex1)
                        {
                            Console.WriteLine(ex1.Message);

                        }
                        break;
                        
                      
                            
                       

                    }
                case 2:
                    {
                        try
                        {
                            Console.WriteLine("Enter the FD Amount:");
                            double _amn = double.Parse(Console.ReadLine());
                            Console.WriteLine("Enter the number of days:");
                            int _day = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter your Age:");
                            int m = int.Parse(Console.ReadLine());
                            ValidateNumber(_amn, _day, m);
                            FDAccount f = new FDAccount(_amn, _day, m);
                            f.CalculateInterest();
                        }
                        catch (NegativeNumberException ex1)
                        {
                            Console.WriteLine(ex1.Message);

                        }
                        
                        break;
                    }
                case 3:
                    {
                        try
                        {
                            Console.WriteLine("Enter the RD Amount:");
                            double _amn = double.Parse(Console.ReadLine());
                            ValidateNumber(_amn);
                            RDAccount r = new RDAccount(_amn);
                            r.CalculateInterest();
                        }
                        catch (NegativeNumberException ex1)
                        {
                            Console.WriteLine(ex1.Message);

                        }
                        break;
                    }
                case 4:
                    j = 4;
                    break;

            }
        }
    }
}