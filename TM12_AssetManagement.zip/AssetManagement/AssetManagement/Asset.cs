﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class Asset
    {
        public int ASSETID;
        public string ASSETTYPE;
        public string SERIALNO;
        public DateTime PROCUREMENTDATE;
        public string TAGGINGSTATUS;
        public Asset(string ASSETTYPE)
        {
            this.ASSETTYPE = ASSETTYPE;

           

        }

    }
}
