﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class Employee
    {
        public string EmployeeID;
        public string EmployeeName;
        public DateTime DateofJoining;
        public string Loaction;
        public string Email;
        public string Phone;
        public Employee(string EmployeeID, string EmployeeName, DateTime DateofJoining, string Loaction, string Email, string Phone)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.DateofJoining = DateofJoining;
            this.Loaction = Loaction;
            this.Email = Email;
            this.Phone = Phone;
        }
    }
}
