﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography.X509Certificates;
using System.Reflection.Emit;

namespace AssetManagement
{



    class Program
    {
        static void Main(string[] args)
        {
            AssetTracking n = new AssetTracking();
           
            bool d = true;
            while (d)
            {
                Console.WriteLine(" 1.Adding Asset\n 2.Modify Asset\n 3.Tagging asset \n 4.Detagging Asset \n 5.EXIT\n");
                int k = GenerateChoice();
                switch (k)
                {
                    case 1:

                        Console.WriteLine("enter the assettype for insert asset :");
                        string astype = Console.ReadLine();
                        n.AddAsset(new Asset(astype));
                        break;
                    case 2:

                        Console.WriteLine("enter name of  the assettype after modify the asset :");
                        string mastype = Console.ReadLine();
                        n.ModifyAsset(new Asset(mastype));

                        break;
                  
                    case 3:

                        Console.WriteLine("enter the employeeid for tagging asset:");
                        string eid = (Console.ReadLine());
                        Console.WriteLine("enter the assetid for tagging asset:");
                        int aid =Convert.ToInt16( Console.ReadLine());
                        n.TagAsset(new AssetTagging(eid, aid));
                        break;
                    case 4:
                        Console.WriteLine("enter the assetid which you want to detagging :");
                        int adid = Convert.ToInt16(Console.ReadLine());
                        n.DeTagAsset(adid);
                        break;
                    case 5:
                        Console.WriteLine("exiting.....");
                        d = false;
                        break;

         
                }

            }

        }
        public static  int GenerateChoice()
        { 
            Console.WriteLine("enter the choice:");
            int l = Convert.ToInt16(Console.ReadLine());
            return l;
        }

    }
}

