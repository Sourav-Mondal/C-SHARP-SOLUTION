﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace AssetManagement
{
    class AssetTracking
    {
        SqlConnection con = new SqlConnection("server=LAPTOP-GU7F36C5;initial catalog= AssetManagement;integrated security=true");
        SqlCommand cmd = new SqlCommand();

        public bool AddAsset(Asset obj)
        {
            string sno = GenereateSerialNo(obj.ASSETTYPE);
            obj.SERIALNO = sno;
            try
            {
                cmd.CommandText = "insert into Asset(ASSETTYPE,SEERIALNO,PROCUREMENTDATE) values (@assettype,@serialno,@pDate) ";
                cmd.Parameters.AddWithValue("@assettype", obj.ASSETTYPE);
                cmd.Parameters.AddWithValue("@serialno", obj.SERIALNO);
                cmd.Parameters.AddWithValue("@pDate", DateTime.Now);
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();


                Console.WriteLine("insert operation sucessful");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return true;
        }
        public string GenereateSerialNo(string s)
        {
            String token = "";
            token = token + s[0] + s[1];
            Random r = new Random();
            int x = r.Next(1000);
            string num = x.ToString();
            token += num;
            return token;
        }
        public bool ModifyAsset(Asset obj)
        {
            try
            {
                Console.WriteLine("enter the assetid to find the asset for modify:");
                int assid = int.Parse(Console.ReadLine());
                
                string sno= GenereateSerialNo(obj.ASSETTYPE);
                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Update Asset Set ASSETTYPE = @astype ,SEERIALNO = @assno , PROCUREMENTDATE = @prodate  Where ASSETID = @asId ";
                sqlCommand.Parameters.AddWithValue("@astype", obj.ASSETTYPE);
                sqlCommand.Parameters.AddWithValue("@assno", sno);
                sqlCommand.Parameters.AddWithValue("@prodate", DateTime.Now);
                sqlCommand.Parameters.AddWithValue("@asId", assid);
                sqlCommand.Connection = con;
                con.Open();
                int changes = sqlCommand.ExecuteNonQuery();
                if (changes == 1)
                {
                    Console.WriteLine("update operation sucessful\n");
                    return true;
                }
                else
                {
                    Console.WriteLine("update operation not sucessful\n");
                    return false;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            return true;
        }
        public bool TagAsset(AssetTagging obj)
        {

            try
            {
                SqlConnection con = new SqlConnection("server=LAPTOP-GU7F36C5;initial catalog= AssetManagement;integrated security=true");

                SqlCommand command = new SqlCommand();
                command.CommandText = "Select Count(*) from Asset Where ASSETID = @asId and TAGGINGSTATUS = @tgstatus;";
                command.Parameters.AddWithValue("@tgstatus", "FREEPOOL");
                command.Parameters.AddWithValue("@asId", obj.ASSETID);
                command.Connection = con;
                con.Open();
                int count = Convert.ToInt32(command.ExecuteScalar());
                if (count != 0)
                {
                    SqlCommand sqlCommand = new SqlCommand();

                    sqlCommand.CommandText = "Insert into assettagging values (@empId , @asId , @tagDate,null); Update Asset Set TAGGINGSTATUS = @tgStatus Where ASSETID = @asId ;";
                    sqlCommand.Parameters.AddWithValue("@empId", obj.EMPLOYEEID);
                    sqlCommand.Parameters.AddWithValue("@asId", obj.ASSETID);
                    sqlCommand.Parameters.AddWithValue("@tagDate", DateTime.Now);
                    sqlCommand.Parameters.AddWithValue("@tgStatus", "Tagged");
                    sqlCommand.Connection = con;
                    sqlCommand.ExecuteNonQuery();
                    Console.WriteLine("assettagging is successfull");
                    return true;

                }
                else
                {
                    Console.WriteLine("Here is no asset is under FREEPOOL\n");
                    
                   
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("assettagging isnot successful\n");
                Console.WriteLine(e.Message);
                
                return false;
            }
            finally
            {
                con.Close();
            }
            return true;
        }
        public bool DeTagAsset(int intAssetID)
        {
            try
            {
                SqlCommand sqlCommand = new SqlCommand();
                sqlCommand.CommandText = "Select Count(*) from Asset Where ASSETID = @apId and TAGGINGSTATUS = @tgstatus;";
                sqlCommand.Parameters.AddWithValue("@tgstatus", "Tagged");
                sqlCommand.Parameters.AddWithValue("@apId", intAssetID);
                sqlCommand.Connection = con;
                con.Open();
                int count = Convert.ToInt32(sqlCommand.ExecuteScalar());
                if (count != 0)
                {
                    sqlCommand.CommandText = "Update ASSETTAGGING Set RELEASEDATE = @rdate Where ASSETID = @asId ;Update asset Set TAGGINGSTATUS= @ts where ASSETID = @asId";
                    sqlCommand.Parameters.AddWithValue("@rdate", DateTime.Now);
                    sqlCommand.Parameters.AddWithValue("@asId", intAssetID);
                    sqlCommand.Parameters.AddWithValue("@ts", "FREEPOOL");

                    sqlCommand.Connection = con;
                   
                    sqlCommand.ExecuteNonQuery();
                    Console.WriteLine("Detagging is successful\n");
                    return true;
                }
                else
                {
                    Console.WriteLine("No asset is tagged in that asset id\n");
                    

                }

            }
            catch(Exception e)
            {
                Console.WriteLine("detagging isnot successful\n");
                Console.WriteLine(e.Message);
                return false;

            }
            finally
            {
                con.Close();
            }
            return true;

        }
    }
}
