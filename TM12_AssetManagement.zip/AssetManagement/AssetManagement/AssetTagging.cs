﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssetManagement
{
    class AssetTagging
    {
        public string EMPLOYEEID;
        public int ASSETID;
        public DateTime TAGGINGDATE;
        public DateTime RELEASEDATE;
        public AssetTagging(string EMPLOYEEID, int ASSETID)
        {
            this.EMPLOYEEID = EMPLOYEEID;
            this.ASSETID = ASSETID;
           
        }
    }
}
