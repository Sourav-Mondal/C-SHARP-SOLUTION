use AssetManagement
create table employee(
EmployeeId varchar(10) primary key,
EmployeeName Varchar(20) not null,
DateofJoining date not null,
Location varchar(20) not null,
Email varchar(30)not null,
Phone varchar(10)not null)

insert into employee(EmployeeId,EmployeeName,DateofJoining,Location,Email,Phone) values('JO123456','John','2011/01/01','HYDERBAD','john@xyz.com',
'123456789'),('SM123456','Smith','2011/11/15','CHENNAI','smith@xyz.com',
'123456789')
create table asset(
ASSETID int identity primary key,
ASSETTYPE varchar(20) check (ASSETTYPE='LAPTOP' OR ASSETTYPE='DESKTOP' OR ASSETTYPE='VOIP' OR ASSETTYPE='DATACARD'),
SEERIALNO varchar(20) not null,
PROCUREMENTDATE date not null,TAGGINGSTATUS varchar(9) default 'FREEPOOL')
create table assettagging(
EMPLOYEEID varchar(10),
ASSETID int ,
TAGGINGDATE date not null,RELEASEDATE DATE ,
FOREIGN KEY (EMPLOYEEID) REFERENCES EMPLOYEE(EmployeeID),
FOREIGN KEY (ASSETID) REFERENCES ASSET(ASSETID))
select * from asset
select * from employee
select * from assettagging
