--  DISPLAY THE DEPARTMENT NAME WITH TOTAL SALARY PAID BY EACH DEPARTMENT
use pubs

select deptname,sum(salary) from department group by deptname