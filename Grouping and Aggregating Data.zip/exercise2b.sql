 --DISPLAY THE TOTAL NUMBER OF EMPLOYEES IN EACH GRADE
 select j.job_desc ,count(*) as 'numbers of employees in each grade' from jobs j ,employee e where j.job_id=e.job_id
 group by j.job_desc