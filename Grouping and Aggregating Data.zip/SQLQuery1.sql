--  DISPLAY THOSE EMPLOYEES WHOSE SALARY IS MINIMUM
use pubs

select concat(fname,' ',lname),min(salary) as 'full name' from employee group by department 