use pubs

select * from employee
select * from jobs
select * from authors
select * from discounts
select * from pub_info
select * from roysched
select * from publishers
select * from sales
select * from stores
select * from titles
select * from titleauthor



