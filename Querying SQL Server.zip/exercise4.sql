use pubs
select title from titles where price>$20 and price<$55 