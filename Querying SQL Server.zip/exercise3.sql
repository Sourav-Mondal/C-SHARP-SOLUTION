use pubs
select title_id,price as 'oldprice',price+0.02 as 'new price' from titles