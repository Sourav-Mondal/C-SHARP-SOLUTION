use pubs
select concat(fname,' ',lname) from employee where year(hire_date)='1981'