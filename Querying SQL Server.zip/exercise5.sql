use pubs
--Frame a Query to Display  data for all the employees who joined after  '1-12-90' have 4 � 6 years of experience.
select CONCAT(fname,' ',lname) from employee where hire_date>'1/12/90' and ((datediff(yy,hire_date,getdate())) between 4 and 6)
 