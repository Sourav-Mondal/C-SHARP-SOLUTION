use pubs
select t.title ,count(t.title_id) from titles t join publishers p on t.pub_id=p.pub_id join titleauthor ta on ta.title_id=t.title_id
join sales s on s.title_id=ta.title_id where 
p.pub_name='new moon books' group by t.title
