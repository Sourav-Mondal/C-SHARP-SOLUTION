use pubs
select t.title from titles t join publishers p on t.pub_id=p.pub_id and p.city like 'B%'