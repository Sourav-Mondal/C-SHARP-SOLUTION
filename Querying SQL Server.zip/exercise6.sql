use pubs
select concat(fname,' ',lname),hire_date from employee 
 