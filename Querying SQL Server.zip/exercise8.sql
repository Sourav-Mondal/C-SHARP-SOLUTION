use pubs
select p.pub_name from publishers p join titles t on t.pub_id=t.pub_id where t.title='Net Etiquette'