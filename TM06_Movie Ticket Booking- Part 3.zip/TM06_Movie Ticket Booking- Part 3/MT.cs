using System;
using System.Collections.Generic;

class MovieTicketing
{
    public List<User> UserInformation { get; set; }
    public string st = null;
    public MovieTicketing()
    {
        User u = new User("Admin", "Admin", "Admin");
        User x = new User("Agent", "Agent", "Agent");
        UserInformation = new List<User>();
        UserInformation.Add(u);
        UserInformation.Add(x);
        List<Theatre> t = new List<Theatre>();
        List<Movie> m = new List<Movie>();
        List<Show> s = new List<Show>();
        List<Booking> b = new List<Booking>();

    }
}
class Theatre
{

}
class Movie
{

}
class Show
{

}
class Booking
{

}
class User
{
    public String Username { get; set; }
    public String Password { get; set; }
    public String UserType { get; set; }


    public User(string username, string password, string userType)
    {
        Username = username;
        Password = password;
        UserType = userType;
    }
}
class Menu : MovieTicketing
{
    public Menu():base()
    {

    }
    public void AdminMenu()
    {
        Console.WriteLine("--------------------------------------------------------------------");
        Console.WriteLine("1. Add Theatre\n2. Update Theatre\n3. Add Movie\n4. Update Movie\n5. Add Show\n6. Update Show\n7. Delete Show\n8. Display Theatres\n9. Display Movies\n10. Display Shows\n11. Add Agent\n12. Book ticket\n13. Print Ticket\n14. Exit.");

    }
    public void AgentMenu()
    {
        Console.WriteLine("--------------------------------------------------------------------");
        Console.WriteLine("1. View Shows\n2. New Ticket\n3. Print Ticket\n4. Exit");

    }
    public int GetChoice()
    {
        Console.WriteLine("Please enter your choice");
        int c = int.Parse(Console.ReadLine());
        return c;
    }
    public string Login()
    {

        Console.Write(" Enter UserName :");
        string s = Console.ReadLine();
        Console.Write(" Enter Password :");
        string p = Console.ReadLine();
        if (UserInformation.Count != 0)
        {
            foreach (var o in UserInformation)
            {
                if (o.Username == s && o.Password == p)
                {
                    st = o.UserType;
                    break;
                }
            }
        }
        return st;

    }
    public static void Main(string[] args)
    {
        Menu m = new Menu();
        bool z = true;
        while (z)
        {
            string lo = m.Login();
            if (lo == null)
            {
                Console.WriteLine("Invalid UserName and Password. Please try again.");
                continue;
            }
            if (lo == "Admin")
            {
                m.AdminMenu();
            }
            if (lo == "Agent")
            {
                m.AgentMenu();
            }
        }
    }
}


